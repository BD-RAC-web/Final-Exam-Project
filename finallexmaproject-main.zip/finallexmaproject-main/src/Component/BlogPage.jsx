import React from "react";
import { GoArrowUpRight } from "react-icons/go";
import { BsArrowRight } from "react-icons/bs";
import projecpageimg from "../assets/propage.jpg";
import pic from "../assets/pic.jpeg";

const BlogPage = () => {
  return (
    <>
      <div>
        <div className="text-[#E2DCC8] relative w-full">
          <img
            src={projecpageimg}
            alt="banner"
            className="w-full h-auto object-cover"
          />
          <div className="absolute   transform -translate-y-[700px] translate-x-[10px]">
            <h2 className="text-[76px] font-medium uppercase">projects</h2>
          </div>
          <div className="absolute transform -translate-y-[700px] translate-x-[10px] mt-[130px]">
            <div className="w-[550px] h-[312px] mt-[130px] uppercase  ">
              <div className="py-[10px] px-4 border-2 flex justify-between cursor-pointer hover:bg-amber-700">
                <h4 className="">BERLING agency website</h4>
                <GoArrowUpRight className="text-3xl" />
              </div>
              <div className="py-[10px] px-4 border-2 flex justify-between cursor-pointer hover:bg-amber-700">
                <h4 className="">Prettylittlething american shop</h4>
              </div>
              <div className="py-[10px] px-4 border-2 flex justify-between cursor-pointer hover:bg-amber-700">
                <h4 className="">Benhome - Architecture theme</h4>
              </div>
              <div className="py-[10px] px-4 border-2 flex justify-between cursor-pointer hover:bg-amber-700">
                <h4 className="">Gilhouse - architecture website</h4>
              </div>
              <div className="py-[10px] px-4 border-2 flex justify-between cursor-pointer hover:bg-amber-700">
                <h4 className="">gilber - personal website</h4>
              </div>
              <div className="py-[10px] px-4 border-2 flex justify-between cursor-pointer hover:bg-amber-700">
                <h4 className="">jonny - personal website</h4>
              </div>
              <div
                className="flex items-center gap-[27px] mt-[50px] ml-[150px]
                      "
              >
                <p className="text-2xl">(hire me :)</p>
                <button className="p-1 px-5 cursor-pointer hover:bg-white hover:text-[#B66449] bg-[#B66449] rounded-[25px] flex ju items-center text-[50px]">
                  <BsArrowRight />
                </button>
              </div>
            </div>
          </div>
          <div>
            <div className="w-[850px] h-[650px] absolute transform -translate-y-[700px] translate-x-[600px] bg-amber-800">
              <div
                className="w-[850px] h-[650px] bg-cover bg-center"
                style={{ backgroundImage: `url(${pic})` }}
              ></div>
            </div>
          </div>
        </div>
      </div>
    </>
  );
};

export default BlogPage;
