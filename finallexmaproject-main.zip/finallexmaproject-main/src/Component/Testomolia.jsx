import React from "react";
import teastomoniaimg from "../assets/tastomoniaimg.jpg";
import brand1 from "../assets/brand1.png";
import brand2 from "../assets/brand2.png";
import brand3 from "../assets/brand3.png";
import brand4 from "../assets/brand4.png";
import handlogo from "../assets/hand.png";
import { GoArrowLeft } from "react-icons/go";
import { GoArrowRight } from "react-icons/go";


const Testomolia = () => {
  return (
    <>
      <div className="w-full relative text-[#E2DCC8] ">
        <img
          src={teastomoniaimg}
          alt="banner"
          className="w-full h-auto object-cover"
        />
        <div className="flex ">
          <div className="absolute transform -translate-y-[750px] translate-x-[10px]">
            <div className="text-[100px] font-medium text-[#E2DCC8] flex gap-[120px] ">
              <span>+250</span>
            </div>
            <p className="mt-[-30px] ml-5">
              I love my work and every project is my pride
            </p>
            <h1 className="text-[100px] font-medium mt-[-30px] ml-[150px] ">
              GREAT
            </h1>
            <h1 className="text-[100px] font-medium mt-[-60px] ml-[30px] uppercase">
              clients
            </h1>
            <div className="mt-[150px] grid grid-cols-2 space-y-6 ml-11">
              <img src={brand1} alt="" />
              <img src={brand2} alt="" />
              <img src={brand3} alt="" />
              <img src={brand4} alt="" />
            </div>
          </div>
          <div className="absolute   transform -translate-y-[720px] translate-x-[560px] ">
            <h4 className="text-[40px] ml-5 w-[514px] ">
              <span className="text-[#B66449]">Creative</span> & dedicated is
              things that my studio brings for your business
            </h4>
            <div className="flex gap-[100px] mt-[120px] ml-[250px]">
              <img src={handlogo} alt="" />
              <p className="w-[380px]">
                “ If you are seeking an Interior designer that will understand
                exactly your needs, and someone who will utilise their creative
                and technical skills in parity with your taste, then Suzanne at
                The Bauhaus Studio is perfect.
              </p>
            </div>
            <div className="ml-[450px] mt-[70px]">
              <h4 className="text-[24px] uppercase ">david & elisa</h4>
              <p>Apartment view lake at Brooklyn</p>
            </div>
            <div className="flex gap-[35px] ml-[600px] mt-[20px] ">
              <button className="w-[112px] h-[77px] border-2 text-2xl rounded-full flex items-center justify-center hover:bg-transparent hover:border-2">
                <GoArrowLeft />
              </button>
              <button className="w-[112px] h-[77px] bg-[#B66449] text-2xl rounded-full flex items-center justify-center hover:bg-transparent hover:border-2">
                <GoArrowRight />
              </button>
            </div>
          </div>
        </div>
      </div>
    </>
  );
};

export default Testomolia;
