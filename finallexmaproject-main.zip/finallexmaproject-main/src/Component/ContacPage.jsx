import React from "react";
import { GoArrowUpRight } from "react-icons/go";
import { BsArrowRight } from "react-icons/bs";
import projecpageimg from "../assets/propage.jpg";

const ContacPage = () => {
  return (
    <>
      <div>
        <div className="text-[#E2DCC8] relative w-full">
          <img
            src={projecpageimg}
            alt="banner"
            className="w-full h-auto object-cover"
          />
          <div className="absolute   transform -translate-y-[700px] translate-x-[10px]">
            <div className="text-[100px] font-medium text-[#E2DCC8] flex gap-[120px] ">
              <span>Hire</span>
              <span>ME</span>
            </div>
          </div>
          <div className="absolute transform -translate-y-[700px] translate-x-[10px] mt-[130px]">
            <div className="w-[550px] h-[312px] mt-[130px] uppercase  ">
              <div className="py-[10px] px-4 border-2 flex justify-between cursor-pointer hover:bg-amber-700">
                <h4 className="">BERLING agency website</h4>
                <GoArrowUpRight className="text-3xl" />
              </div>
              <div className="py-[10px] px-4 border-2 flex justify-between cursor-pointer hover:bg-amber-700">
                <h4 className="">Benhome - Architecture theme</h4>
              </div>
              <div className="py-[10px] px-4 border-2 flex justify-between cursor-pointer hover:bg-amber-700">
                <h4 className="">Gilhouse - architecture website</h4>
              </div>
              <div className="py-[10px] px-4 border-2 flex justify-between cursor-pointer hover:bg-amber-700">
                <h4 className="">gilber - personal website</h4>
              </div>
              <div className="py-[10px] px-4 border-2 flex justify-between cursor-pointer hover:bg-amber-700">
                <h4 className="">jonny - personal website</h4>
              </div>
              <div className="flex items-center gap-[27px] mt-[50px] ml-[150px]">
                <p className="text-2xl">(hire me :)</p>
                <button className="p-1 px-5 cursor-pointer hover:bg-white hover:text-[#B66449] bg-[#B66449] rounded-[25px] flex ju items-center text-[50px]">
                  <BsArrowRight />
                </button>
              </div>
            </div>
          </div>
          <div>
            <div className="w-[850px] h-[650px] absolute transform -translate-y-[700px] translate-x-[600px]">
              <h4 className="text-[40px] ml-5 w-[500px] ">
                Let's grab a coffee and jump on{" "}
                <span className="text-[#B66449]">conversation</span> chat with
                me.
              </h4>
              <div className="mt-[150px] flex gap-12 justify-between items-center">
                <div>
                  <h5 className="uppercase underline py-10">send a brief</h5>
                  <p>
                    I recommend filling out a brief to assess the cost of the
                    project.{" "}
                  </p>
                </div>
                <div className="w-[495px] h-[305px] ">
                  <input type="text" placeholder="NAME" className=" w-[80%] h-[50px] px-6 border-b-2 focus:outline-none" />
                  <input type="text" placeholder="NAME" className=" w-[80%] h-[50px] px-6 border-b-2 focus:outline-none" />
                  <input type="text" placeholder="NAME" className=" w-[80%] h-[50px] px-6 border-b-2 focus:outline-none" />
                  <button className="p-1 px-5 cursor-pointer mt-[100px] hover:bg-white hover:text-[#B66449] bg-[#B66449] rounded-[25px] flex ju items-center text-[50px]">
                  <BsArrowRight />
                </button>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </>
  );
};

export default ContacPage;
