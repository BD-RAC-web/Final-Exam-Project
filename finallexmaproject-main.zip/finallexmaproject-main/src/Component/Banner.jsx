import React from "react";
import banner from "../assets/banner.jpg";
import { BsArrowRight } from "react-icons/bs";
import logo1 from "../assets/logo1.jpeg";
import logo2 from "../assets/logo2.jpeg";

const Banner = () => {
  return (
    <div className="w-full relative text-[#E2DCC8]">
      <img src={banner} alt="banner" className="w-full h-auto object-cover" />
      <div className="flex ">
        <div className="absolute transform -translate-y-[700px] translate-x-[10px]">
          <div className="text-[100px] font-medium text-[#E2DCC8] flex gap-[120px] ">
            <span>GET</span>
            <span>YOUR</span>
          </div>
          <p className="mt-[-30px] ml-5">
            Always available for freelance work, contact me and get your greate
            design ;){" "}
          </p>
          <h1 className="text-[100px] font-medium mt-[-30px]">GREAT</h1>
          <h1 className="text-[100px] font-medium mt-[-70px] ml-[130px]">
            Design
          </h1>
          <p className="w-[380px] ml-5 mt-5">
            Hello, my name is Pattison and i am UX/UI designer and front-end
            developer, im working via developer 9 years and i know all about
            design
          </p>
          <div
            className="flex items-center gap-[27px] mt-[50px] ml-[150px]
        "
          >
            <p className="text-2xl">(hire me :)</p>
            <button className="p-2 px-9 cursor-pointer hover:bg-white hover:text-[#B66449] bg-[#B66449] rounded-[25px] flex ju items-center text-[70px]">
              <BsArrowRight />
            </button>
          </div>
          <div className="mt-[20px] flex justify-between items-center px-2">
            <div className="flex items-center gap-5">
              <h2 className="text-[70px] font-medium">8</h2>
              <p>
                Years <br /> experience
              </p>
            </div>
            <div className="flex items-center gap-5">
              <h2 className="text-[70px] font-medium">5</h2>
              <p>
                Themeforest <br />
                awwards
              </p>
            </div>
            <div className="flex items-center gap-5">
              <h2 className="text-[70px] font-medium">60</h2>
              <p>
                Projects <br /> Done
              </p>
            </div>
          </div>
        </div>
        <div className="mt-10">
          <div className="absolute   transform -translate-y-[700px] translate-x-[600px]">
            <div
              className="w-[508px] h-[508px] rounded-full bg-cover bg-center"
              style={{ backgroundImage: `url(${logo1})` }}
            ></div>
          </div>
          <div className="absolute   transform -translate-y-[700px] translate-x-[1000px]">
            <div
              className="w-[508px] h-[508px] rounded-full bg-cover bg-center"
              style={{ backgroundImage: `url(${logo2})` }}
            ></div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Banner;
