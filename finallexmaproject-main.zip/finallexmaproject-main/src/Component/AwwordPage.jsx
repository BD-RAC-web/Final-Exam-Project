import React from "react";
import awwardimg from "../assets/propage.jpg";
import { BsArrowRight } from "react-icons/bs";
const AwwordPage = () => {
  return (
    <>
      <div className="w-full relative text-[#E2DCC8]">
        <img
          src={awwardimg}
          alt="banner"
          className="w-full h-auto object-cover"
        />
        <div className="absolute   transform -translate-y-[700px] translate-x-[10px]">
          <div className="text-[100px] font-medium text-[#E2DCC8] flex gap-[50px] ">
            <span>Explore</span>
            <span>MY</span>
          </div>
          <p className="mt-[-20px] ml-5">
            I love my work and every project is my pride
          </p>
          <h1 className="text-[100px] font-medium mt-[-40px] ml-[130px]">
            PROFILE
          </h1>
          <p className="w-[380px] ml-5 mt-5">
            Hello, my name is Pattison and i am UX/UI designer and front-end
            developer, im working via developer 9 years and i know all about
            design
          </p>
          <div
            className="flex items-center gap-[27px] mt-[50px] ml-[150px]
                 "
          >
            <p className="text-2xl">(hire me :)</p>
            <button className="p-2 px-9 cursor-pointer hover:bg-white hover:text-[#B66449] bg-[#B66449] rounded-[25px] flex ju items-center text-[70px]">
              <BsArrowRight />
            </button>
          </div>
        </div>
        <div className="absolute   transform -translate-y-[660px] translate-x-[560px] ">
          <h4 className="text-[40px] ml-5">
            Professional <span className="text-[#B66449]">awards</span>
          </h4>
          <div className="w-[960px] h-[125px]  border-b-2 mt-10 ">
            <div className="flex justify-between px-10">
              <div className="w-[85px] h-[85px] bg-[#C4C4C4]"></div>
              <div className="">
                <p>
                  1ST WINNER CREATIVE <br /> DESIGN CHAMPIONSHIP
                </p>
              </div>
              <div className="">
                <p>
                  For most favorited design voted by NY City Style <br />{" "}
                  customers
                </p>
              </div>
            </div>
          </div>
          <div className="w-[960px] h-[100px]  border-b-2 mt-10 ">
            <div className="flex justify-between px-10">
              <div className="w-[85px] h-[85px] bg-[#C4C4C4]"></div>
              <div className="">
                <p>
                  1ST WINNER CREATIVE <br /> DESIGN CHAMPIONSHIP
                </p>
              </div>
              <div className="">
                <p>
                  For most favorited design voted by NY City Style <br />{" "}
                  customers
                </p>
              </div>
            </div>
          </div>
          <div className="w-[960px] h-[100px]  border-b-2 mt-10 ">
            <div className="flex justify-between px-10">
              <div className="w-[85px] h-[85px] bg-[#C4C4C4]"></div>
              <div className="">
                <p>
                  1ST WINNER CREATIVE <br /> DESIGN CHAMPIONSHIP
                </p>
              </div>
              <div className="">
                <p>
                  For most favorited design voted by NY City Style <br />{" "}
                  customers
                </p>
              </div>
            </div>
          </div>
          <div className="w-[960px] h-[100px]  mt-10 ">
            <div className="flex justify-between px-10">
              <div className="w-[85px] h-[85px] bg-[#C4C4C4]"></div>
              <div className="">
                <p>
                  1ST WINNER CREATIVE <br /> DESIGN CHAMPIONSHIP
                </p>
              </div>
              <div className="">
                <p>
                  For most favorited design voted by NY City Style <br />{" "}
                  customers
                </p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </>
  );
};

export default AwwordPage;
