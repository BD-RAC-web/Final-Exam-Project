import React from "react";
import { FaFacebookF } from "react-icons/fa";
import { IoLogoTwitter } from "react-icons/io5";
import { FaLinkedin } from "react-icons/fa";
import { NavLink } from "react-router";

const Navber = () => {
  return (
    <>
      <div className="w-full h-[70px] text-white text-[16px] flex justify-between items-center px-5 absolute  bg-transparent z-10 border-b-2">
        <div className="flex gap-8">
          <FaFacebookF className="cursor-pointer hover:text-amber-600" />
          <IoLogoTwitter className="cursor-pointer hover:text-amber-600" />
          <FaLinkedin className="cursor-pointer hover:text-amber-600" />
        </div>
        <div>
          <ul className="flex gap-16">
            <li className="hover:text-amber-600">
              {" "}
              <a href="">Home</a>{" "}
            </li>
            <li className="hover:text-amber-600">
              <a href="">Projects</a>
            </li>
            <li className="hover:text-amber-600">
              <a href="">awwards</a>
            </li>
            <li className="hover:text-amber-600">
              <a href="">testimonials</a>
            </li>
            <li className="hover:text-amber-600">
              <a href="">blog</a>
            </li>
            <li className="hover:text-amber-600">
              <a href="">CONTACT</a>
            </li>
          </ul>
        </div>
        <h5>+2(315) 590 83 68</h5>
      </div>
    </>
  );
};

export default Navber;
