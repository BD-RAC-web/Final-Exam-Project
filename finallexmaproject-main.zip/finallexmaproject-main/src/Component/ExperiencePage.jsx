import React from "react";
import iphonebg from "../assets/iphone.png";
import fb from '../assets/fb.png'
import tw from '../assets/tw.png'
import t from '../assets/t.png'
import ing from '../assets/in.png'
import linkdin from '../assets/li.png'
const ExperiencePage = () => {
  return (
    <>
      <div className="w-full relative text-[#E2DCC8]">
        <img
          src={iphonebg}
          alt="banner"
          className="w-full h-auto object-cover"
        />
        <div className="flex">
          <div className="absolute transform -translate-y-[700px] translate-x-[10px]">
            <div className="text-[80px] font-medium text-[#E2DCC8] flex gap-[70px] ">
              <span className="uppercase">Education</span>
              <span>&</span>
            </div>
            <p className="mt-[-30px] ml-3">
              Professional awards I’ve reached during my working times.
            </p>
            <h1 className="text-[80px] font-medium mt-[-30px] uppercase ml-[80px]">
              experience
            </h1>
            <p className="w-[380px] ml-5 mt-5">
              I have been developing sites for 8 years and I know for sure the
              main trends and directions of modern design, you will get a decent
              result
            </p>
            <button className=" cursor-pointer hover:bg-white hover:text-[#B66449] bg-[#B66449] rounded-[25px] flex ju items-center py-[10px] px-[30px] text-2xl uppercase ml-[260px] mt-[100px]">
              resume
            </button>
          </div>
          <div className="absolute transform -translate-y-[660px] translate-x-[560px] ">
            <div className="w-[960px] h-[125px] border-b-2 border-r-2 border-l-2 mt-10  ">
              <div className="flex justify-between items-center px-10 mt-6">
                <div className="w-[85px] h-[85px]">
                   <div
                    className="w-[50px] h-[50px] mt-4 bg-cover bg-center"
                    style={{ backgroundImage: `url(${fb})` }}
                  ></div>
                </div>
                <div className="">
                  <p>
                    1ST WINNER CREATIVE <br /> DESIGN CHAMPIONSHIP
                  </p>
                </div>
                <div className="">
                  <p>
                    For most favorited design voted by NY City Style <br />{" "}
                    customers
                  </p>
                </div>
              </div>
            </div>
            <div className="w-[960px] h-[100px] border-b-2 border-r-2 border-l-2">
              <div className="flex justify-between px-10">
                <div className="w-[85px] h-[85px] pt-3 ">
                  
                  <div
                    className="w-[50px] h-[50px] mt-4 bg-cover bg-center"
                    style={{ backgroundImage: `url(${tw})` }}
                  ></div>
                </div>
                <div className="">
                  <p>
                    1ST WINNER CREATIVE <br /> DESIGN CHAMPIONSHIP
                  </p>
                </div>
                <div className="">
                  <p>
                    For most favorited design voted by NY City Style <br />{" "}
                    customers
                  </p>
                </div>
              </div>
            </div>
            <div className="w-[960px] h-[100px] border-b-2 border-r-2 border-l-2">
              <div className="flex justify-between px-10">
                <div className="w-[85px] h-[85px] "> <div
                    className="w-[50px] h-[50px] mt-4 bg-cover bg-center"
                    style={{ backgroundImage: `url(${t})` }}
                  ></div></div>
                <div className="">
                  <p>
                    1ST WINNER CREATIVE <br /> DESIGN CHAMPIONSHIP
                  </p>
                </div>
                <div className="">
                  <p>
                    For most favorited design voted by NY City Style <br />{" "}
                    customers
                  </p>
                </div>
              </div>
            </div>
            <div className="w-[960px] h-[100px] border-b-2 border-r-2 border-l-2  ">
              <div className="flex justify-between px-10 pt-3.5">
                <div className="w-[85px]  h-[85px]"> <div
                    className="w-[50px] h-[50px] mt-4 bg-cover bg-center"
                    style={{ backgroundImage: `url(${ing})` }}
                  ></div></div>
                <div className=" ">
                  <p>
                    1ST WINNER CREATIVE <br /> DESIGN CHAMPIONSHIP
                  </p>
                </div>
                <div className="">
                  <p>
                    For most favorited design voted by NY City Style <br />{" "}
                    customers
                  </p>
                </div>
              </div>
            </div>
            <div className="w-[960px] h-[100px] border-b-2 border-r-2 border-l-2  ">
              <div className="flex justify-between px-10 pt-3.5">
                <div className="w-[85px]  h-[85px]"> <div
                    className="w-[50px] h-[50px] mt-4 bg-cover bg-center"
                    style={{ backgroundImage: `url(${linkdin})` }}
                  ></div></div>
                <div className=" ">
                  <p>
                    1ST WINNER CREATIVE <br /> DESIGN CHAMPIONSHIP
                  </p>
                </div>
                <div className="">
                  <p>
                    For most favorited design voted by NY City Style <br />{" "}
                    customers
                  </p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </>
  );
};

export default ExperiencePage;
