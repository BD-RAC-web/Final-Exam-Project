import { useState } from 'react'
import './App.css'
import Navber from './Component/Navber'
import Banner from './Component/Banner'
import ProjectPage from './Component/ProjectPage'
import AwwordPage from './Component/AwwordPage'
import Testomolia from './Component/Testomolia'
import ExperiencePage from './Component/ExperiencePage'
import BlogPage from './Component/BlogPage'
import ContacPage from './Component/ContacPage'

function App() {
  const [count, setCount] = useState(0)

  return (
    <>
     <Navber/>
     <Banner/>
     < ProjectPage/>
     <AwwordPage/>
     <Testomolia/>
     <ExperiencePage/>
     <BlogPage/>
     <ContacPage/>
    </>
  )
}

export default App
